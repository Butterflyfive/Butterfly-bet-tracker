
# Butterfly Bet Tracker

🦋 A simple, elegant app to log your daily MLB bets, track results, and stay disciplined using the Butterfly Five method.

Built with [Streamlit](https://streamlit.io), ready for deployment on Streamlit Cloud.
